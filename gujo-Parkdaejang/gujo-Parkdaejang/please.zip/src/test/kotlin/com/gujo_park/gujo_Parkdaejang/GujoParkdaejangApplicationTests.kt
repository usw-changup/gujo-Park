package com.gujo_park.gujo_Parkdaejang

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GujoParkdaejangApplicationTests {

	@Test
	fun contextLoads() {
	}

}
