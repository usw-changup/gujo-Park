package com.gujo_park.gujo_Parkdaejang.repository

interface PhotoRepository {
}