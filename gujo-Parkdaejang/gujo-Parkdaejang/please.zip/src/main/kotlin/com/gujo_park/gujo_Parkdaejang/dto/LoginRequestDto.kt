package com.gujo_park.gujo_Parkdaejang.dto

data class LoginRequestDto (
    val username: String,
    val password: String
)
